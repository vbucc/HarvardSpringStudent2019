#' @title Get Prices
#'
#' @description Gets Recent prices from TCGPlayer.com.  Accepts the set name but some characters need to be escaped, see the examples.
#'
#' @param TCGplayerSetName string of the set name to be pasted into a final URL e.g. "Mirrodin" and in some cases characters need to be escaped as they are URL encoded
#' @export
#' @seealso \link[BoosterBox]{crackPack}
#' @return res a data frame of information with card name, casting cost, set name, rarity, high, medium and low prices.  Any missing/NA are changed to 0.
#' @examples  \dontrun{
#' DMaze<-getTCGprices("Dragon\'s Maze")
#' Mir<-getTCGprices('Mirrodin')
#' err<-getTCGprices('Mirridin') # will error but print the url for reference
#' }
getTCGprices<-function(TCGplayerSetName){
  require(XML)
  require(RCurl)

  # Get URL
  nam<-URLencode(TCGplayerSetName,reserved=T)
  addr<-paste0('http://magic.tcgplayer.com/db/search_result.asp?Set_Name=',nam)
  cat(paste('Getting ',addr,'\n'))

  # Get Data
  dat<-getURL(addr,.opts = list(ssl.verifypeer = FALSE) )
  tables <- readHTMLTable(dat)
  tableDF<-unlist(lapply(tables,is.data.frame))
  tables<-tables[tableDF]
  numRows<-unlist(lapply(tables,nrow))

  # Organize Data
  res<-tables[[which.max(numRows)]]
  names(res)<-c('Name','Cost','Set','R','High','Med','Low')

  # Clean up
  res$High<-gsub('[$]','',res$High)
  res$Med<-gsub('[$]','',res$Med)
  res$Low<-gsub('[$]','',res$Low)
  res$High<-as.numeric(as.character(res$High))
  res$High[is.na(res$High)]<-0

  res$Med<-as.numeric(as.character(res$Med))
  res$Med[is.na(res$Med)]<-0

  res$Low<-as.numeric(as.character(res$Low))
  res$Low[is.na(res$Low)]<-0
  return(res)
}




