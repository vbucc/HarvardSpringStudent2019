#' @title Open Box
#'
#' @description Simulates opening a booster box.  The number of packs must be declared and is usually 24 or 36.  Each pack contains 15 cards made of 11 common, 3 uncommon and 1 rare or mythic.  Packs per mythic and foil are declared parameters with defaults as 8 and 6 respectively.  Other defaults include having foils and mythics although older sets do not have them and in that case should be set to F.  These later params are sent to crackPack.
#'
#' @param spoiler - the set information which is a data frame of cards with R (rarity) High, Med, and Low pricing.  Can be obtained from getTCGprices or constructed as a data frame with Name, Cost, SetName, R, High, Med, Low, foil names.
#' @param packsPerMythic the number of packs to open before likely getting a mythic.  Default is 8 packs.
#' @param packsPerFoil the number of packs to open before likely getting a mythic.  Default is 6 packs.  For sets with a foil in each pack like Masters change to 1.
#' @param foilsInSet boolean T/F are foils in the set.
#' @export
#' @seealso \link[BoosterBox]{crackPack}
#' @return res a data frame of information with card name, casting cost, set name, rarity, high, medium and low prices.
#' @examples  \dontrun{
#' # has foils, no mythics
#' cold<-getTCGprices('Coldsnap')
#' coldBox<-openBox(cold,numPacks=36)
#'
#' # no foils, no mythics
#' saga<-getTCGprices("Urza\'s Saga")
#' sagaBox<-openBox(cold,numPacks=36,foilsInSet=F)
#'
#' # foils in every pack, mythics, 24 packs
#' data(modernMasters13)
#' masterBox<-openBox(modernMasters13,24, packsPerFoil=1)
#'
#' #Mythics, foils, 36 packs
#' data("JourneyIntoNyx")
#' nyxBox<-openBox(JourneyIntoNyx,36)
#' }
openBox<-function(spoiler,numPacks=36,packsPerMythic=8,packsPerFoil=6,foilsInSet=T){
  boosterBox<-list()
  for (i in 1:numPacks){
    cat(paste('opening pack',i,'\n'))
    pack<-crackPack(spoiler,packsPerMythic,packsPerFoil,foilsInSet)
    nam<-i
    boosterBox[[nam]]<-pack
  }
  boosterBox<-do.call(rbind,boosterBox)
  return(boosterBox)
}

