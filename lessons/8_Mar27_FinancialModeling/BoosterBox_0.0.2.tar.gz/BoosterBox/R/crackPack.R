#' @title Crack Pack
#'
#' @description Simulates opening a pack.  15 cards made of 11 common, 3 uncommon and 1 rare or mythic.  Packs per mythic and foil are declared parameters with defaults as 8 and 6 respectively.  Other defaults include having foils and mythics although older sets do not have them and in that case should be set to F.
#'
#' @param spoiler - the set information which is a data frame of cards with R (rarity) High, Med, and Low pricing.  Can be obtained from getTCGprices or constructed as a data frame with Name, Cost, SetName, R, High, Med, Low, foil names.
#' @param packsPerMythic the number of packs to open before likely getting a mythic.  Default is 8 packs.
#' @param packsPerFoil the number of packs to open before likely getting a mythic.  Default is 6 packs.  For sets with a foil in each pack like Masters change to 1.
#' @param foilsInSet boolean T/F are foils in the set. Default is T.
#' @export
#' @seealso \link[BoosterBox]{getTCGprices}
#' @return res a data frame of information with card name, casting cost, set name, rarity, high, medium and low prices.
#' @examples  \dontrun{
#' # From TCG Directly
#' DMaze<-getTCGprices("Dragon\'s Maze")
#' crackPack(DMaze)
#'
#' Mir<-getTCGprices('Mirrodin')
#' crackPack(Mir)
#'
#' #From a data frame of information
#' data("modernMasters13")
#' data("JourneyIntoNyx")
#' data("Kaladesh")
#' crackPack(modernMasters13)
#' crackPack(JourneyIntoNyx)
#' crackPack(Kaladesh)
#' }
crackPack<-function(spoiler,packsPerMythic=8,packsPerFoil=6,foilsInSet=T){
  # Spoiler organization
  mythics<-subset(spoiler,spoiler$R=='M')
  rares<-subset(spoiler,spoiler$R=='R')
  uncommons<-subset(spoiler,spoiler$R=='U')
  commons<-subset(spoiler,spoiler$R=='C')
  spoiler<-spoiler[!(grepl('T',spoiler$R)),] #drop tokens
  spoiler<-spoiler[!(grepl('L',spoiler$R)),] #drop tokens

  # Pick a pack
  commons<-spoiler%>%filter(R=='C') %>% sample_n(11)
  uncommons<-spoiler%>%filter(R=='U') %>% sample_n(3)

  if(nrow(mythics)>0){
    mythicCheck<-sample(c(0,1),1,prob=c(1-(1/packsPerMythic),1/packsPerMythic))
    if(mythicCheck==0){
      premium<-spoiler%>%filter(R=='R')%>% sample_n(1)
    } else {
      premium<-spoiler%>%filter(R=='M')%>% sample_n(1)
    }
  } else {
    premium<-spoiler%>%filter(R=='R')%>% sample_n(1)
  }

  if(foilsInSet==T){
    foilCheck<-sample(c(0,1),1,prob=c(1-(1/packsPerFoil),1/packsPerFoil))
    if(foilCheck==1){
      foil<-spoiler%>% sample_n(1)
      commons<-commons%>%sample_n(10) #foil replaces a common; so you could get 2 rares
      boosterPack<-rbind(commons,uncommons, premium, foil)
      boosterPack$foil<-c(rep('FALSE',14),'TRUE')
    } else {
      boosterPack<-rbind(commons,uncommons, premium)
      boosterPack$foil<-c(rep('FALSE',15))
    }

  } else {
    boosterPack<-rbind(commons,uncommons, premium)
    boosterPack$foil<-c(rep('FALSE',15))
  }


 return(boosterPack)
}
