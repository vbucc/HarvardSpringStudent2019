#' @title Card Values
#'
#' @description After a simulated opening, will use the random triangle distribution to derive a total value for the cards.  It factors in rarity, and foil using 1000 random distribution samples from TCG pricing.
#'
#' @param cards - the pack, or box card list which is a data frame of cards with R (rarity) High, Med, and Low pricing.
#' @param worthlessCommons boolean T/F so that non-foil commons are counted as 0.  Default is T.  If F then non foil common pricing has a low of the casrds "TCG Low" a high value of "TCG Med" and a mode of "TCG Low".  These parameters are sampled 1000 times to derive an average using the rtriangle distribution.
#' @param verbose boolean default F so only the total will be returned, if T then each card will get a price according to the distributions and appended to the card data frame.
#' @export
#' @seealso \link[BoosterBox]{openBox}
#' @return the total expected value from the cards provided
#' @examples  \dontrun{
#' DMaze<-getTCGprices("Dragon\'s Maze")
#' MazePack<-crackPack(DMaze)
#' cardValues(MazePack)
#' cardValues(MazePack, worthlessCommons=F)
#' cardValues(MazePack,worthlessCommons=T, verbose=T)
#'
#' data(modernMasters13)
#' masterBox<-openBox(modernMasters13,24, packsPerFoil=1)
#' print(head(masterBox))
#' cardValues(masterBox)
#' }
cardValues<-function(cards, worthlessCommons=T, verbose=F){
  #Get nonfoil prices
  commons<-subset(cards,cards$R=='C' & cards$foil==F)
  uncommons<-subset(cards,cards$R=='U'& cards$foil==F)
  rares<-subset(cards,cards$R=='R' & cards$foil==F)
  mythics<-subset(cards,cards$R=='M' & cards$foil==F)

  #Random Dist of nonfoil prices
  if(worthlessCommons==T){
    commonsP<-0
  } else {
    commonsP<-lapply(Map(rtriangle,1000,commons$Low,commons$Med,commons$Low), mean) %>%unlist()
  }

  uncommonsP<-lapply(Map(rtriangle,1000,uncommons$Low,uncommons$Med,uncommons$Low), mean) %>%unlist()

  if(nrow(rares)==0){
    raresP<-0
  } else {
    raresP<-lapply(Map(rtriangle,1000,rares$Low,rares$Med,rares$Med), mean) %>%unlist()
  }

  if(nrow(mythics)==0){
    mythicsP<-0
  } else {
    mythicsP<-lapply(Map(rtriangle,1000,mythics$Low,mythics$Med,mythics$Med), mean) %>%unlist()
  }

  #Get foil prices
  commonsF<-subset(cards,cards$R=='C' & cards$foil==T)
  uncommonsF<-subset(cards,cards$R=='U'& cards$foil==T)
  raresF<-subset(cards,cards$R=='R' & cards$foil==T)
  mythicsF<-subset(cards,cards$R=='M' & cards$foil==T)

  #Random Dist of foil prices
  if(nrow(commonsF)==0){
    commonsFP<-0
  } else {
    commonsFP<-lapply(Map(rtriangle,1000,commonsF$Low,commonsF$Med,commonsF$Low), mean) %>%unlist()
  }
  if(nrow(uncommonsF)==0){
    uncommonsFP<-0
  } else {
    uncommonsFP<-lapply(Map(rtriangle,1000,uncommonsF$Low,uncommonsF$Med,uncommonsF$Low), mean) %>%unlist()
  }
  if(nrow(raresF)==0){
    raresFP<-0
  } else {
    raresFP<-lapply(Map(rtriangle,1000,raresF$Low,raresF$Med,raresF$Low), mean) %>%unlist()
  }
  if(nrow(mythicsF)==0){
    mythicsFP<-0
  } else {
    mythicsFP<-lapply(Map(rtriangle,1000,mythicsF$Med,mythicsF$High,mythicsF$High), mean) %>%unlist()
  }

  if(verbose==F){
    # Res
    res<-sum(commonsP,uncommonsP,raresP,mythicsP,commonsFP,uncommonsFP,raresFP,mythicsFP)
  } else {

    resC<-data.frame(commons, TCGdistPrice=commonsP)
    resU<-data.frame(uncommons, TCGdistPrice=uncommonsP)
    if(nrow(rares)>0){
      resP<-data.frame(rares,TCGdistPrice=raresP)
    } else {
      resP<-NULL
    }
    if(nrow(mythics)>0){
      resM<-data.frame(mythics,TCGdistPrice=mythicsP)
    } else {
      resM<-NULL
    }
    if(nrow(commonsF)>0){
      resFC<-data.frame(commonsF,TCGdistPrice=commonsFP)
    } else {
      resFC<-NULL
    }
    if(nrow(uncommonsF)>0){
      resFU<-data.frame(uncommonsF,TCGdistPrice=uncommonsFP)
    } else {
      resFU<-NULL
    }
    if(nrow(raresF)>0){
      resFR<-data.frame(raresF,TCGdistPrice=raresFP)
    } else {
      resFR<-NULL
    }
    if(nrow(mythicsF)>0){
      resFM<-data.frame(mythicsF,TCGdistPrice=mythicsFP)
    } else {
      resFM<-NULL
    }
    res<-rbind(resC,resU,resP,resM,resFC,resFU,resFR,resFM)
    }

  return(res)
}
#
